#!/usr/bin/env bash
#
# table-extractor: Markdownファイルから[TABLE STRT]〜[TABLE END]で囲まれたテーブル領域を抽出する
#
# Usage: ./extractor.sh <input.md>
# Output: JSON formatted table blocks

set -euo pipefail

INPUT_FILE="${1:?Usage: $0 <input.md>}"

if [ ! -f "$INPUT_FILE" ]; then
  echo "Error: File not found: $INPUT_FILE" >&2
  exit 1
fi

in_table=0
table_index=0
table_content=""

echo "{"
echo '  "tables": ['

while IFS= read -r line; do
  if [[ "$line" =~ ^\[TABLE\ STRT\] ]]; then
    in_table=1
    table_content="$line"$'\n'
  elif [[ "$line" =~ ^\[TABLE\ END\] ]]; then
    in_table=0
    table_content+="$line"
    
    if [ $table_index -gt 0 ]; then
      echo ","
    fi
    
    # Escape JSON special characters
    escaped_content=$(echo "$table_content" | python3 -c "
import sys, json
content = sys.stdin.read()
print(json.dumps(content))
" 2>/dev/null || echo "$table_content" | sed 's/"/\\"/g' | awk '{printf "%s\\n", $0}')
    
    cat <<TABLE_ENTRY
    {
      "index": $table_index,
      "content": $escaped_content
    }
TABLE_ENTRY
    
    table_index=$((table_index + 1))
    table_content=""
  elif [ $in_table -eq 1 ]; then
    table_content+="$line"$'\n'
  fi
done < "$INPUT_FILE"

echo ""
echo '  ]'
echo "}"

echo "Extraction complete: $table_index table(s) found." >&2

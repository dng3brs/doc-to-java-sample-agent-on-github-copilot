#!/usr/bin/env bash
#
# markdown-splitter: 単一Markdownファイルをレベル1ヘッダ(#)単位で分割する
#
# Usage: ./splitter.sh <input.md>
# Output: overview.md, methods/ directory with individual method files

set -euo pipefail

INPUT_FILE="${1:?Usage: $0 <input.md>}"
OUTPUT_DIR="$(dirname "$INPUT_FILE")/split-output"

mkdir -p "$OUTPUT_DIR/methods"

# Extract overview section (from start to first level-1 header after the first)
awk '
  /^# / && !found_first {
    found_first = 1
    header = $0
    next
  }
  /^# / && found_first && !saved_first {
    saved_first = 1
    print > "'"$OUTPUT_DIR"'/overview.md"
    close("'"$OUTPUT_DIR"'/overview.md")
    header = $0
    method_index = 1
    next
  }
  /^# / && saved_first {
    close(file)
    file = "'"$OUTPUT_DIR"'/methods/method_" sprintf("%02d", method_index) ".md"
    method_index++
    print $0 > file
    next
  }
  saved_first {
    if (file != "") print $0 > file
  }
  !saved_first {
    if (found_first) print $0 > "'"$OUTPUT_DIR"'/overview.md"
  }
' "$INPUT_FILE"

echo "Split complete:"
echo "  Overview: $OUTPUT_DIR/overview.md"
echo "  Methods: $OUTPUT_DIR/methods/"
ls -1 "$OUTPUT_DIR/methods/" 2>/dev/null | wc -l | xargs echo "    Count:"
